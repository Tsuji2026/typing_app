package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.util.ArrayList;
import java.util.List;

public class QuestionAddActivity extends AppCompatActivity {
    public static List<ListData> typingList;
    public static int typingList_max;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i("QuestionAddActivity", "call onCreate()");
        TypingAdapter typingAdapter;

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_question_add);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseHelper = new DatabaseHelper(this);
        typingList = new ArrayList<ListData>();
        typingList_max = databaseHelper.getAllTyping(typingList);

        // リストビューにデータ表示
        typingAdapter = new TypingAdapter(this, typingList);
        ListView userListView = findViewById(R.id.userListView);
        userListView.setAdapter(typingAdapter);
    }

    @Override
    protected void onStart() {
        Log.i("QuestionAddActivity", "call onStart()");
        super.onStart();
    }

    @Override
    protected void onResume() {
        Log.i("QuestionAddActivity", "call onResume()");
        super.onResume();
    }

    @Override
    protected void onPause() {
        Log.i("QuestionAddActivity", "call onPause()");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.i("QuestionAddActivity", "call onStop()");
        super.onStop();
    }

    @Override
    protected void onRestart() {
        Log.i("QuestionAddActivity", "call onRestart()");
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        Log.i("QuestionAddActivity", "call onDestroy()");
        super.onDestroy();
    }

    // 問題追加
    public void click_add_csv(View view) {
        Log.i("QuestionAddActivity", "call click_add()");
        TextView add_text;
        String add_question_text;
        int add_question_text_len;
        ListData add_data = new ListData();
        databaseHelper = new DatabaseHelper(this);

        add_text = findViewById(R.id.add_text);
        add_question_text = String.valueOf(add_text.getText());
        add_question_text_len = Integer.parseInt(String.valueOf(add_text.length()));

        if(databaseHelper.setTyping(MainActivity.typingList_max + 1, add_question_text, add_question_text_len)) {
            MainActivity.typingList_max++;
            MainActivity.typingList.add(add_data);
        }
    }

    public void click_go_home(View v) {
        Log.i("QuestionAddActivity", "call click_go_home()");
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }
}